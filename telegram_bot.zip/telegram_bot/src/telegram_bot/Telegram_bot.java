/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package telegram_bot;
import org.json.*;
import telegram_api.test;

/**
 *
 * @author babar_muhammad_anas
 */
public class Telegram_bot {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        test t = new test();
        t.foo();
    }
    
}
